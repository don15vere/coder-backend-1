import { Router } from 'express';

const router = Router();

// Home: render básico; el navegador pedirá productos a /api/products
router.get('/', async (req, res) => {
  res.render('home', {
    title: 'Home',
  });
});

// Realtime Products: alta/baja y lista en vivo
router.get('/realtimeproducts', async (req, res) => {
  res.render('realtimeproducts', {
    title: 'Realtime Products',
  });
});

router.get('/products', (_req, res) => res.render('products/index', { title: 'Productos' }));

router.get('/carts/new', (_req, res) => {
  res.send(`<script>
    fetch('/api/carts',{method:'POST'}).then(r=>r.json()).then(c=>{
      localStorage.setItem('cid', c._id || c.id);
      location.href='/carts/'+(c._id||c.id);
    });
  </script>`);
});

router.get('/carts/:cid', (req, res) =>
  res.render('carts/show', { title: 'Carrito', cid: req.params.cid })
);

export default router;

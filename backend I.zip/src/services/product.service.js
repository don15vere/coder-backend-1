import Product from '../models/product.model.js';

/**
 * GET /api/products
 * Soporta: ?limit=10&page=1&sort=asc|desc&query=<categoria|available|unavailable>
 * - sort: por price
 * - query: si coincide con available/unavailable => filtra por status
 *          en otro caso, filtra por category (y como fallback busca en title/description por regex)
 */
export async function findAll({ limit = 10, page = 1, sort, query } = {}) {
  const lim = Math.max(1, Number(limit) || 10);
  const pg  = Math.max(1, Number(page) || 1);

  const filter = {};
  if (query) {
    const q = String(query).toLowerCase();
    if (['available','unavailable','true','false','1','0'].includes(q)) {
      const on = ['available','true','1'].includes(q);
      filter.status = on;
    } else {
      // si mandan categoría, filtra por category
      filter.$or = [
        { category: query },
        // fallback “búsqueda general” si no era exactamente una categoría conocida
        { title:       { $regex: query, $options: 'i' } },
        { description: { $regex: query, $options: 'i' } },
      ];
    }
  }

  const sortObj = {};
  if (sort && ['asc','desc'].includes(String(sort).toLowerCase())) {
    sortObj.price = String(sort).toLowerCase() === 'asc' ? 1 : -1;
  }

  const [totalDocs, docs] = await Promise.all([
    Product.countDocuments(filter),
    Product.find(filter)
      .sort(sortObj)
      .skip((pg - 1) * lim)
      .limit(lim)
      .lean()
  ]);

  const totalPages = Math.max(1, Math.ceil(totalDocs / lim));
  return {
    payload: docs,
    totalDocs,
    totalPages,
    page: pg,
    limit: lim,
    hasPrevPage: pg > 1,
    hasNextPage: pg < totalPages,
    prevPage: pg > 1 ? pg - 1 : null,
    nextPage: pg < totalPages ? pg + 1 : null
  };
}

export async function findById(id) {
  return Product.findById(id).lean();
}

export async function create(data) {
  return Product.create(data);
}

export async function update(id, data) {
  return Product.findByIdAndUpdate(id, data, { new: true, runValidators: true, lean: true });
}

export async function remove(id) {
  return Product.findByIdAndDelete(id).lean();
}

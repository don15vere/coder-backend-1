# Backend I – Entrega 1

Servidor en **Node.js + Express** con gestión de **productos** y **carritos**, persistiendo en archivos `products.json` y `carts.json`.

## Requisitos
- Node 18+
- npm

## Instalación
```bash
npm install
npm run dev
# o
npm start